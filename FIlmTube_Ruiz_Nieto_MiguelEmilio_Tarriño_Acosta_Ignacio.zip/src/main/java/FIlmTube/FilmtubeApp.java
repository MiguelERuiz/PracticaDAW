package FIlmTube;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmtubeApp {
    public static void main(String[] args) {
        SpringApplication.run(FilmtubeApp.class, args);
    }
}

