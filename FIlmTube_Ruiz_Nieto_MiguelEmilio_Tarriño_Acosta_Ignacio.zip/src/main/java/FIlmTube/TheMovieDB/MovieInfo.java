package FIlmTube.TheMovieDB;

// Esta clase se utiliza para parsear los datos mas relevantes de la pelicula que devuelve la API

public class MovieInfo {

    private String overview;
    private String poster_path;
    private String release_date;
    private String vote_average;


    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getPoster_path() {
        return poster_path;
    }

    public void setPoster_path(String poster_path) {
        this.poster_path = poster_path;
    }

    public String getRelease_date() {
        return release_date;
    }

    public void setRelease_date(String release_date) {
        this.release_date = release_date;
    }

    public String getVote_average() {
        return vote_average;
    }

    public void setVote_average(String vote_average) {
        this.vote_average = vote_average;
    }
}
