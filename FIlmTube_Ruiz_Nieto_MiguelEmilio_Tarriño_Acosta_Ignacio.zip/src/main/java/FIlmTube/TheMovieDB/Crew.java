package FIlmTube.TheMovieDB;

// Esta clase se utiliza para parsear la informacion del equipo que realizo la pelicula que te devuelve la API

public class Crew {

    private String credit_id;
    private String department;
    private String job;
    private String name;

    public String getCredit_id() {
        return credit_id;
    }

    public void setCredit_id(String credit_id) {
        this.credit_id = credit_id;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Crew{" +
                "credit_id='" + credit_id + '\'' +
                ", department='" + department + '\'' +
                ", job='" + job + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
